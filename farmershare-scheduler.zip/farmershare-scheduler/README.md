# FarmerShare Scheduler

**Agricultural equipment rental and idle-time exchange for local farming communities.**

FarmerShare helps farmers find equipment listed by other local farmers, submit rental requests for selected dates, and share free time for equipment or farm services such as a water pump. It is a beginner-friendly full-stack MVP built with HTML, CSS, Vanilla JavaScript, Node.js, Express, and Supabase PostgreSQL.

> **Important demo limitation:** this version has no login or verified user ownership. Its SQL policies are deliberately open so students can run the demo with a Supabase anon key. Do not publish it for real personal data or real bookings without adding Supabase Auth, ownership checks, stricter RLS policies, and an owner approval workflow. Do not put a Supabase service-role key in this project.

## Features

- Browse, search, and filter available equipment.
- List a tractor, ploughing tool, harvesting machine, irrigation tool, transport vehicle, or other equipment with a daily rate and contact details.
- Send rental requests with a date range; the server calculates the estimated total and checks overlapping pending/approved requests.
- Publish idle-time slots for equipment or services by date and time.
- Send interest in an idle-time slot.
- Responsive layout for phones, tablets, and desktops.
- Server-side input checks, rate limiting, security headers, and persistent Supabase PostgreSQL storage.

## Technology and architecture

- Frontend: `frontend/index.html`, `frontend/styles.css`, `frontend/app.js`
- Backend: Node.js + Express in `backend/`
- Database: Supabase PostgreSQL; schema in `database/schema.sql`
- The browser calls `/api/...` endpoints. Express validates inputs and talks to Supabase. Data is not stored only in browser memory.

## Folder structure

```text
farmershare-scheduler/
├── frontend/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── backend/
│   ├── routes/
│   │   └── api.js
│   ├── utils/
│   │   └── validation.js
│   ├── server.js
│   ├── supabase.js
│   ├── package.json
│   ├── .env.example
│   └── .gitignore
├── database/
│   └── schema.sql
├── .gitignore
└── README.md
```

## Requirements

Install Node.js 18 or newer. You also need a Supabase account and a project. The core app does not require a paid service or an external API beyond Supabase database hosting.

## 1. Create and configure Supabase

1. Open [Supabase](https://supabase.com/) and create a project.
2. In the project dashboard, open **SQL Editor**.
3. Open `database/schema.sql` from this project, copy all of its contents, paste into a new SQL query, and run it.
4. Confirm that the `equipment`, `rental_requests`, `idle_slots`, and `idle_slot_requests` tables exist in **Table Editor**.
5. Open **Project Settings → API** (or the project's API keys page). Copy the Project URL and the **anon/publishable** key. Never use a service-role/secret key for this demo.

The included SQL policies allow public demo reads/writes. That is convenient for a classroom MVP, not production-ready. Because phone numbers are stored, use test data only until authentication and stricter policies have been added.

## 2. Install and run

Open a terminal in the root `farmershare-scheduler` folder.

```bash
cd backend
npm install
```

Create your local environment file by copying the template:

**Windows PowerShell**
```powershell
Copy-Item .env.example .env
```

**Windows Command Prompt**
```bat
copy .env.example .env
```

**macOS / Linux**
```bash
cp .env.example .env
```

Edit `backend/.env` and add your own values:

```env
PORT=3000
NODE_ENV=development
SUPABASE_URL=https://YOUR_PROJECT_ID.supabase.co
SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```

- `PORT`: local web server port.
- `NODE_ENV`: environment mode.
- `SUPABASE_URL`: Project URL from Supabase.
- `SUPABASE_ANON_KEY`: anon/publishable key from Supabase. It is intended for client-like access and is protected by RLS policies; it is not a service-role key.

Start the server:

```bash
npm start
```

Open **http://localhost:3000** in your browser. Keep the terminal open while using the app. For development with automatic restart on supported Node versions, use `npm run dev`.

## 3. Main API routes

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/health` | Check whether the Express server is running |
| GET | `/api/equipment` | List available equipment; supports `search` and `category` query parameters |
| POST | `/api/equipment` | Create an equipment listing |
| GET | `/api/bookings` | List rental requests (optional `phone` filter) |
| POST | `/api/bookings` | Submit a rental request and calculate estimated cost |
| GET | `/api/idle-slots` | List open upcoming idle-time slots |
| POST | `/api/idle-slots` | Publish an idle-time slot |
| POST | `/api/idle-slots/:id/request` | Send interest in an idle-time slot |

## 4. Example user workflows

### List equipment
Select **List equipment**, enter equipment details, owner contact, village, and daily price, then publish. The new listing should appear in the equipment board.

### Request a rental
Select **Request rental** on a listing. Enter your name, phone number, and start/end dates. The server estimates the cost using inclusive calendar days. A request is pending until the owner contacts you and confirms it outside the app.

### Share idle time
Select **Share available time**, enter the resource, village, date, and time range. Other users can select **I'm interested** to send their contact details and a message.

## 5. Test checklist

- [ ] `GET http://localhost:3000/api/health` returns `{ "status": "ok", ... }`.
- [ ] Equipment page loads after the SQL schema and environment variables are configured.
- [ ] Equipment search and category filter update the list.
- [ ] Submitting an equipment listing with all required fields adds a row to `equipment`.
- [ ] Missing equipment name, owner, phone, village, or invalid rate is rejected with a helpful error.
- [ ] A rental request with a valid date range is saved in `rental_requests`.
- [ ] A rental request whose end date is before its start date is rejected.
- [ ] A conflicting pending/approved rental request for the same equipment and dates is rejected.
- [ ] An idle-time slot appears in the community availability board.
- [ ] Interest in an idle slot is saved in `idle_slot_requests`.
- [ ] The layout remains usable at phone width.

## 6. Troubleshooting

**The page says Supabase is not configured**: make sure the file is named `backend/.env`, not `.env.example`, and that you replaced the placeholder values. Restart the server after editing `.env`.

**Supabase returns a relation/table error**: run the entire `database/schema.sql` script in the correct Supabase project's SQL Editor.

**Permission denied / row-level security error**: check that the schema script ran completely and the policies exist. Never fix this by exposing a service-role key in the browser. For a production app, design proper user-level RLS policies.

**Port already in use**: change `PORT=3000` to another free port in `backend/.env`, then restart.

**Equipment image is blank**: the image URL is optional; use a valid direct HTTPS image URL or leave it empty.

**npm command not found**: install Node.js 18+ from [nodejs.org](https://nodejs.org/) and reopen the terminal.

## 7. Security and next steps

This is a learning MVP, not a complete production rental marketplace. Before real use, implement Supabase Auth, verified ownership for listings and requests, owner-only approval/rejection endpoints, privacy-aware phone visibility, abuse protection, booking conflict protection at the database level, and tighter RLS policies. Consider requiring owner approval before treating any rental as confirmed. Do not store or share real personal contact data in a public classroom demo.

## 8. Upload to GitHub

From the project root (`farmershare-scheduler`):

```bash
git init
git status
git add .
git status
git commit -m "Build FarmerShare Scheduler"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Replace `YOUR_GITHUB_REPOSITORY_URL` with the URL of the repository you created on GitHub. Before the first commit, confirm that `backend/.env`, `node_modules/`, database exports, and personal information are not included. `.env.example` should be included, but it must contain only placeholders. `.gitignore` does not remove a secret that has already been committed; if a secret is exposed, rotate it immediately and remove it from repository history as appropriate.

## Project status

The source files and SQL schema are included in this folder. Syntax checks can be run with `cd backend && npm run check`. The remote database and browser workflow have not been verified against your personal Supabase project; those steps require your own credentials and setup.
