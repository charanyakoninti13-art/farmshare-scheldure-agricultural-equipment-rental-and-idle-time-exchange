const text = (value, max = 120) => typeof value === 'string' ? value.trim().slice(0, max) : '';
const number = (value) => Number(value);
const validDate = (value) => /^\d{4}-\d{2}-\d{2}$/.test(String(value || '')) && !Number.isNaN(Date.parse(`${value}T00:00:00Z`));
module.exports = { text, number, validDate };
