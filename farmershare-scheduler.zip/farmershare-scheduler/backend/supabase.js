const { createClient } = require('@supabase/supabase-js');

let client = null;
function getSupabase() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_ANON_KEY;
  if (!url || !key || url.includes('YOUR_PROJECT_ID') || key.includes('YOUR_SUPABASE')) {
    const error = new Error('Supabase is not configured. Copy backend/.env.example to backend/.env and add your project URL and anon key.');
    error.status = 503;
    throw error;
  }
  if (!client) client = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
  return client;
}
module.exports = { getSupabase };
