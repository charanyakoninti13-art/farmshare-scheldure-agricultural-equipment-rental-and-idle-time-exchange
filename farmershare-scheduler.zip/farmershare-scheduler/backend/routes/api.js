const express = require('express');
const { getSupabase } = require('../supabase');
const { text, number, validDate } = require('../utils/validation');
const router = express.Router();

const asyncRoute = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const dbError = (error) => { const e = new Error(error.message || 'Database request failed'); e.status = 400; return e; };

router.get('/health', (_req, res) => res.json({ status: 'ok', app: 'FarmerShare Scheduler' }));

router.get('/equipment', asyncRoute(async (req, res) => {
  const db = getSupabase();
  let query = db.from('equipment').select('*').eq('is_available', true).order('created_at', { ascending: false });
  if (req.query.search) {
    const search = text(req.query.search, 80).replace(/[,%()]/g, '');
    if (search) query = query.or(`name.ilike.%${search}%,category.ilike.%${search}%,village.ilike.%${search}%`);
  }
  if (req.query.category && req.query.category !== 'All equipment') query = query.eq('category', text(req.query.category, 60));
  const { data, error } = await query.limit(100);
  if (error) throw dbError(error);
  res.json(data || []);
}));

router.post('/equipment', asyncRoute(async (req, res) => {
  const body = req.body || {};
  const item = {
    name: text(body.name, 100), category: text(body.category, 60), description: text(body.description, 600),
    owner_name: text(body.owner_name, 100), phone: text(body.phone, 20), village: text(body.village, 100),
    rate_per_day: number(body.rate_per_day), image_url: text(body.image_url, 500) || null, is_available: true
  };
  if (!item.name || !item.category || !item.owner_name || !item.phone || !item.village || !Number.isFinite(item.rate_per_day) || item.rate_per_day < 0 || item.rate_per_day > 1000000) {
    return res.status(400).json({ error: 'Please provide equipment name, category, owner, phone, village and a valid daily rate.' });
  }
  if (!/^[+\d()\-\s]{7,20}$/.test(item.phone)) return res.status(400).json({ error: 'Enter a valid phone number.' });
  const { data, error } = await getSupabase().from('equipment').insert(item).select().single();
  if (error) throw dbError(error);
  res.status(201).json(data);
}));

router.get('/bookings', asyncRoute(async (req, res) => {
  const db = getSupabase();
  let query = db.from('rental_requests').select('*, equipment(name, village, rate_per_day)').order('created_at', { ascending: false }).limit(100);
  if (req.query.phone) query = query.eq('renter_phone', text(req.query.phone, 20));
  const { data, error } = await query;
  if (error) throw dbError(error);
  res.json(data || []);
}));

router.post('/bookings', asyncRoute(async (req, res) => {
  const b = req.body || {};
  const equipment_id = text(b.equipment_id, 50);
  const renter_name = text(b.renter_name, 100), renter_phone = text(b.renter_phone, 20);
  const start_date = text(b.start_date, 10), end_date = text(b.end_date, 10);
  if (!equipment_id || !renter_name || !renter_phone || !validDate(start_date) || !validDate(end_date) || end_date < start_date) {
    return res.status(400).json({ error: 'Enter your name, phone, equipment and a valid date range. End date must not be before start date.' });
  }
  if (!/^[+\d()\-\s]{7,20}$/.test(renter_phone)) return res.status(400).json({ error: 'Enter a valid phone number.' });
  const db = getSupabase();
  const { data: equipment, error: lookupError } = await db.from('equipment').select('id, rate_per_day, is_available').eq('id', equipment_id).single();
  if (lookupError || !equipment || !equipment.is_available) return res.status(404).json({ error: 'This equipment is not available.' });
  const days = Math.floor((Date.parse(`${end_date}T00:00:00Z`) - Date.parse(`${start_date}T00:00:00Z`)) / 86400000) + 1;
  if (days < 1 || days > 90) return res.status(400).json({ error: 'Rental duration must be between 1 and 90 days.' });
  const { data: clashes, error: clashError } = await db.from('rental_requests').select('id').eq('equipment_id', equipment_id).in('status', ['pending', 'approved']).lte('start_date', end_date).gte('end_date', start_date);
  if (clashError) throw dbError(clashError);
  if (clashes && clashes.length) return res.status(409).json({ error: 'There is already a pending or approved request for this equipment during those dates.' });
  const row = { equipment_id, renter_name, renter_phone, start_date, end_date, total_cost: days * Number(equipment.rate_per_day), status: 'pending', note: text(b.note, 500) };
  const { data, error } = await db.from('rental_requests').insert(row).select().single();
  if (error) throw dbError(error);
  res.status(201).json(data);
}));

router.get('/idle-slots', asyncRoute(async (_req, res) => {
  const { data, error } = await getSupabase().from('idle_slots').select('*').eq('status', 'open').gte('slot_date', new Date().toISOString().slice(0, 10)).order('slot_date').limit(100);
  if (error) throw dbError(error);
  res.json(data || []);
}));

router.post('/idle-slots', asyncRoute(async (req, res) => {
  const b = req.body || {};
  const row = { owner_name: text(b.owner_name, 100), phone: text(b.phone, 20), village: text(b.village, 100), resource_name: text(b.resource_name, 100), slot_date: text(b.slot_date, 10), start_time: text(b.start_time, 5), end_time: text(b.end_time, 5), note: text(b.note, 500), status: 'open' };
  if (!row.owner_name || !row.phone || !row.village || !row.resource_name || !validDate(row.slot_date) || !/^\d{2}:\d{2}$/.test(row.start_time) || !/^\d{2}:\d{2}$/.test(row.end_time) || row.end_time <= row.start_time) {
    return res.status(400).json({ error: 'Fill all required fields and choose a valid date and time range.' });
  }
  if (!/^[+\d()\-\s]{7,20}$/.test(row.phone)) return res.status(400).json({ error: 'Enter a valid phone number.' });
  const { data, error } = await getSupabase().from('idle_slots').insert(row).select().single();
  if (error) throw dbError(error);
  res.status(201).json(data);
}));

router.post('/idle-slots/:id/request', asyncRoute(async (req, res) => {
  const b = req.body || {};
  const requester_name = text(b.requester_name, 100), requester_phone = text(b.requester_phone, 20);
  if (!requester_name || !/^[+\d()\-\s]{7,20}$/.test(requester_phone)) return res.status(400).json({ error: 'Enter your name and a valid phone number.' });
  const { data, error } = await getSupabase().from('idle_slot_requests').insert({ idle_slot_id: req.params.id, requester_name, requester_phone, message: text(b.message, 500) }).select().single();
  if (error) throw dbError(error);
  res.status(201).json({ message: 'Your interest was sent. Contact the owner to confirm the arrangement.', request: data });
}));

module.exports = router;
