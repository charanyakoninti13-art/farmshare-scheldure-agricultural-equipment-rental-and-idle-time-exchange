const API = '/api';
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
let equipmentCache = [];
let toastTimer;
const escapeHTML = (value = '') => String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
function showToast(message, isError = false) {
  const toast = $('#toast'); toast.textContent = message; toast.classList.toggle('error', isError); toast.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('show'), 3600);
}
async function request(path, options = {}) {
  const response = await fetch(`${API}${path}`, { ...options, headers: { 'Content-Type': 'application/json', ...(options.headers || {}) } });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || `Request failed (${response.status})`);
  return payload;
}
function openModal(id) { const dialog = document.getElementById(id); if (dialog && !dialog.open) dialog.showModal(); }
function closeModal(dialog) { if (dialog?.open) dialog.close(); }
function dateParts(dateValue) {
  const date = new Date(`${dateValue}T12:00:00`);
  return { day: date.toLocaleDateString('en-IN', { day: '2-digit' }), month: date.toLocaleDateString('en-IN', { month: 'short' }).toUpperCase(), full: date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) };
}
function categoryEmoji(category) { return ({Tractor:'🚜',Ploughing:'🌱',Harvesting:'🌾',Irrigation:'💧',Transport:'🚚',Other:'🧰'})[category] || '🧰'; }
function equipmentCard(item) {
  const image = item.image_url ? `<img src="${escapeHTML(item.image_url)}" alt="${escapeHTML(item.name)}" loading="lazy" onerror="this.remove()">` : '';
  return `<article class="equipment-card"><div class="equipment-image">${image}<span class="equipment-emoji">${categoryEmoji(item.category)}</span><span class="category-tag">${escapeHTML(item.category)}</span></div><div class="equipment-content"><div class="equipment-title-row"><div><h3>${escapeHTML(item.name)}</h3><div class="location">⌖ ${escapeHTML(item.village)}</div></div><div class="rate">₹${Number(item.rate_per_day).toLocaleString('en-IN')}<small>/ day</small></div></div><p class="equipment-description">${escapeHTML(item.description || 'Contact the owner to discuss availability and rental terms.')}</p><div class="owner-row"><div class="owner"><b>${escapeHTML(item.owner_name)}</b>Owner · ${escapeHTML(item.phone)}</div><button class="button button-primary book-button" data-id="${escapeHTML(item.id)}">Request rental</button></div></div></article>`;
}
function renderEquipment(items) {
  const list = $('#equipment-list'), empty = $('#equipment-empty');
  list.innerHTML = items.map(equipmentCard).join(''); empty.classList.toggle('hidden', items.length !== 0);
  $$('.book-button', list).forEach(button => button.addEventListener('click', () => {
    const item = equipmentCache.find(row => String(row.id) === button.dataset.id); if (!item) return;
    const form = $('#booking-form'); form.reset(); form.elements.equipment_id.value = item.id;
    $('#booking-item').textContent = `${item.name} · ₹${Number(item.rate_per_day).toLocaleString('en-IN')} per day · ${item.village}`;
    const today = new Date().toISOString().slice(0, 10); form.elements.start_date.min = today; form.elements.end_date.min = today; openModal('booking-modal');
  }));
}
async function loadEquipment() {
  const params = new URLSearchParams(); const search = $('#equipment-search').value.trim(); const category = $('#category-filter').value;
  if (search) params.set('search', search); if (category !== 'All equipment') params.set('category', category);
  try { equipmentCache = await request(`/equipment?${params}`); renderEquipment(equipmentCache); }
  catch (error) { $('#equipment-list').innerHTML = `<div class="loading-card">${escapeHTML(error.message)}<br><br>Set up Supabase using the README, then refresh.</div>`; $('#equipment-empty').classList.add('hidden'); }
}
async function loadIdleSlots() {
  try {
    const slots = await request('/idle-slots');
    if (!slots.length) { $('#idle-list').innerHTML = '<p class="board-loading">No open slots yet. Be the first to share available time.</p>'; return; }
    $('#idle-list').innerHTML = slots.map(slot => { const date = dateParts(slot.slot_date); return `<article class="idle-card"><div class="idle-date"><b>${date.day}</b>${date.month}</div><div class="idle-details"><h3>${escapeHTML(slot.resource_name)} · ${escapeHTML(slot.village)}</h3><p>${escapeHTML(slot.start_time)}–${escapeHTML(slot.end_time)} · ${escapeHTML(slot.owner_name)}<br>${escapeHTML(slot.note || 'Available for coordination')}</p></div><button class="button button-outline interest-button" data-id="${escapeHTML(slot.id)}" data-title="${escapeHTML(slot.resource_name)}" data-village="${escapeHTML(slot.village)}" data-date="${escapeHTML(date.full)}">I'm interested</button></article>`; }).join('');
    $$('.interest-button', $('#idle-list')).forEach(button => button.addEventListener('click', () => { const form = $('#interest-form'); form.reset(); form.elements.slot_id.value = button.dataset.id; $('#interest-item').textContent = `${button.dataset.title} · ${button.dataset.village} · ${button.dataset.date}`; openModal('interest-modal'); }));
  } catch (error) { $('#idle-list').innerHTML = `<p class="board-loading">${escapeHTML(error.message)}<br>Set up Supabase to load community slots.</p>`; }
}
async function submitForm(form, path, onSuccess) {
  const button = $('button[type="submit"]', form); const oldText = button.textContent; button.disabled = true; button.textContent = 'Sending…';
  try { const data = await request(path, { method: 'POST', body: JSON.stringify(Object.fromEntries(new FormData(form).entries())) }); closeModal(form.closest('dialog')); form.reset(); showToast(data.message || 'Saved successfully.'); if (onSuccess) await onSuccess(data); }
  catch (error) { showToast(error.message, true); }
  finally { button.disabled = false; button.textContent = oldText; }
}
$$('[data-open]').forEach(button => button.addEventListener('click', () => openModal(button.dataset.open)));
$$('.close-modal').forEach(button => button.addEventListener('click', () => closeModal(button.closest('dialog'))));
$$('dialog').forEach(dialog => dialog.addEventListener('click', event => { if (event.target === dialog) closeModal(dialog); }));
$('.menu-toggle').addEventListener('click', () => $('nav').classList.toggle('open'));
$$('nav a').forEach(link => link.addEventListener('click', () => $('nav').classList.remove('open')));
let searchTimer; $('#equipment-search').addEventListener('input', () => { clearTimeout(searchTimer); searchTimer = setTimeout(loadEquipment, 250); }); $('#category-filter').addEventListener('change', loadEquipment);
$('#equipment-form').addEventListener('submit', event => { event.preventDefault(); submitForm(event.currentTarget, '/equipment', loadEquipment); });
$('#booking-form').addEventListener('submit', event => { event.preventDefault(); const form = event.currentTarget; if (form.elements.end_date.value < form.elements.start_date.value) return showToast('End date must not be before start date.', true); submitForm(form, '/bookings', loadEquipment); });
$('#idle-form').addEventListener('submit', event => { event.preventDefault(); submitForm(event.currentTarget, '/idle-slots', loadIdleSlots); });
$('#interest-form').addEventListener('submit', event => { event.preventDefault(); const form = event.currentTarget; const slotId = form.elements.slot_id.value; const body = Object.fromEntries(new FormData(form).entries()); delete body.slot_id; submitForm(form, `/idle-slots/${encodeURIComponent(slotId)}/request`, loadIdleSlots); });
$('#year').textContent = new Date().getFullYear();
const today = new Date().toISOString().slice(0, 10); $$('input[type="date"]').forEach(input => input.min = today);
loadEquipment(); loadIdleSlots();
