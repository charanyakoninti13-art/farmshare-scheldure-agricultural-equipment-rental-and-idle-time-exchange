-- FarmerShare Scheduler database schema
-- Run this complete file in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.equipment (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(trim(name)) between 2 and 100),
  category text not null check (category in ('Tractor','Ploughing','Harvesting','Irrigation','Transport','Other')),
  description text not null default '',
  owner_name text not null check (char_length(trim(owner_name)) between 1 and 100),
  phone text not null check (char_length(trim(phone)) between 7 and 20),
  village text not null check (char_length(trim(village)) between 1 and 100),
  rate_per_day numeric(10,2) not null check (rate_per_day >= 0),
  image_url text,
  is_available boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.rental_requests (
  id uuid primary key default gen_random_uuid(),
  equipment_id uuid not null references public.equipment(id) on delete restrict,
  renter_name text not null check (char_length(trim(renter_name)) between 1 and 100),
  renter_phone text not null check (char_length(trim(renter_phone)) between 7 and 20),
  start_date date not null,
  end_date date not null,
  total_cost numeric(12,2) not null check (total_cost >= 0),
  status text not null default 'pending' check (status in ('pending','approved','rejected','cancelled','completed')),
  note text not null default '',
  created_at timestamptz not null default now(),
  check (end_date >= start_date),
  check (end_date - start_date <= 89)
);

create table if not exists public.idle_slots (
  id uuid primary key default gen_random_uuid(),
  owner_name text not null check (char_length(trim(owner_name)) between 1 and 100),
  phone text not null check (char_length(trim(phone)) between 7 and 20),
  village text not null check (char_length(trim(village)) between 1 and 100),
  resource_name text not null check (char_length(trim(resource_name)) between 1 and 100),
  slot_date date not null,
  start_time time not null,
  end_time time not null,
  note text not null default '',
  status text not null default 'open' check (status in ('open','matched','closed')),
  created_at timestamptz not null default now(),
  check (end_time > start_time)
);

create table if not exists public.idle_slot_requests (
  id uuid primary key default gen_random_uuid(),
  idle_slot_id uuid not null references public.idle_slots(id) on delete cascade,
  requester_name text not null check (char_length(trim(requester_name)) between 1 and 100),
  requester_phone text not null check (char_length(trim(requester_phone)) between 7 and 20),
  message text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists equipment_category_village_idx on public.equipment(category, village);
create index if not exists equipment_created_at_idx on public.equipment(created_at desc);
create index if not exists rental_requests_equipment_dates_idx on public.rental_requests(equipment_id, start_date, end_date);
create index if not exists rental_requests_status_idx on public.rental_requests(status);
create index if not exists idle_slots_date_status_idx on public.idle_slots(slot_date, status);
create index if not exists idle_slot_requests_slot_idx on public.idle_slot_requests(idle_slot_id);

-- MVP/demo access: the app has no login system. These policies make the public
-- demo work with the Supabase anon key. Do not use these open write policies for
-- a public production deployment with real contact details. Add Supabase Auth,
-- ownership checks, and narrower policies before production use.
alter table public.equipment enable row level security;
alter table public.rental_requests enable row level security;
alter table public.idle_slots enable row level security;
alter table public.idle_slot_requests enable row level security;

drop policy if exists "Public can view available equipment" on public.equipment;
create policy "Public can view available equipment" on public.equipment for select to anon, authenticated using (is_available = true);
drop policy if exists "Public demo can list equipment" on public.equipment;
create policy "Public demo can list equipment" on public.equipment for insert to anon, authenticated with check (true);

drop policy if exists "Public demo can view rental requests" on public.rental_requests;
create policy "Public demo can view rental requests" on public.rental_requests for select to anon, authenticated using (true);
drop policy if exists "Public demo can request rentals" on public.rental_requests;
create policy "Public demo can request rentals" on public.rental_requests for insert to anon, authenticated with check (true);

drop policy if exists "Public can view open idle slots" on public.idle_slots;
create policy "Public can view open idle slots" on public.idle_slots for select to anon, authenticated using (status = 'open');
drop policy if exists "Public demo can post idle slots" on public.idle_slots;
create policy "Public demo can post idle slots" on public.idle_slots for insert to anon, authenticated with check (true);

drop policy if exists "Public demo can request idle slots" on public.idle_slot_requests;
create policy "Public demo can request idle slots" on public.idle_slot_requests for insert to anon, authenticated with check (true);
